<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PlanController extends Controller
{
    public function plan(){
        return view('plan.index');
    }

    public function plan(){
        return view('plan.index');
    }
}
