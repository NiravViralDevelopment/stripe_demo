<html>
    <head>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <link href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js'></script>
        <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
    </head>
        <style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:400,700&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Montserrat', sans-serif;
}

body {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    /* background-color: #0C4160; */

    padding: 30px 10px;
}

.card {
    max-width: 500px;
    margin: auto;
    color: black;
    border-radius: 20 px;
}

p {
    margin: 0px;
}

.container .h8 {
    font-size: 30px;
    font-weight: 800;
    text-align: center;
}

.btn.btn-primary {
    width: 100%;
    height: 70px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 15px;
    background-image: linear-gradient(to right, #77A1D3 0%, #79CBCA 51%, #77A1D3 100%);
    border: none;
    transition: 0.5s;
    background-size: 200% auto;

}


.btn.btn.btn-primary:hover {
    background-position: right center;
    color: #fff;
    text-decoration: none;
}



.btn.btn-primary:hover .fas.fa-arrow-right {
    transform: translate(15px);
    transition: transform 0.2s ease-in;
}

.form-control {
    color: white;
    background-color: #223C60;
    border: 2px solid transparent;
    height: 60px;
    padding-left: 20px;
    vertical-align: middle;
}

.form-control:focus {
    color: white;
    background-color: #0C4160;
    border: 2px solid #2d4dda;
    box-shadow: none;
}

.text {
    font-size: 14px;
    font-weight: 600;
}

::placeholder {
    font-size: 14px;
    font-weight: 600;
    }
    </style>
    
    <body>
        <div class="container-fluid">
            <div class="row d-flex justify-content-center">
                <div class="col-sm-12">
                    <div class="card mx-auto">
                        <p class="heading">PAYMENT DETAILS</p>
                            <form class="card-details ">
                                <div class="form-group mb-0">
                                        <p class="text-warning mb-0">Card Number</p> 
                                          <input type="text" name="card-num2" placeholder="1234 5678 9012 3457" size="17" id="cno2" minlength="19" maxlength="19">
                                        
                                </div>
        
                                <div class="form-group">
                                    <p class="text-warningw mb-0">Cardholder's Name</p> <input type="text" name="name" placeholder="Name" size="17">
                                </div>
                                <div class="form-group pt-2">
                                    <div class="row d-flex">
                                        <div class="col-sm-4">
                                            <p class="text-warning mb-0">Expiration</p>
                                            <input type="text" name="exp" placeholder="MM/YYYY" size="7" id="exp" minlength="7" maxlength="7">
                                        </div>
                                        <div class="col-sm-3">
                                            <p class="text-warning mb-0">Cvv</p>
                                            <input type="password" name="cvv" placeholder="&#9679;&#9679;&#9679;" size="1" minlength="3" maxlength="3">
                                        </div>
                                        <div class="col-sm-5 pt-0">
                                            <button type="button" class="btn btn-primary"><i class="fas fa-arrow-right px-3 py-2"></i></button>
                                        </div>
                                    </div>
                                </div>		
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\stripe\resources\views/plan/plan_checkout.blade.php ENDPATH**/ ?>